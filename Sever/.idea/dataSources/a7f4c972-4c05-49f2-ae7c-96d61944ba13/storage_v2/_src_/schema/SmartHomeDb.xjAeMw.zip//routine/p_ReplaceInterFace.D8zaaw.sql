CREATE PROCEDURE p_ReplaceInterFace(IN interFaceName_in          TEXT, IN interFaceNameStr_in TEXT,
                                    IN interFaceDescribe_in      TEXT, IN interFacepath_in TEXT,
                                    IN interFaceBeginTime_in     TEXT, IN interFaceEndTime_in TEXT,
                                    IN interFaceBeginVersions_in TEXT, IN interFaceEndVersions_in TEXT)
  BEGIN 

    SELECT COUNT(interFaceName) INTO @Count 
    FROM SmartHomeInterFace_Table 
    WHERE interFaceName = interFaceName_in;
    
    IF @Count>0 THEN
    
        UPDATE SmartHomeInterFace_Table SET 
        interFaceNameStr = interFaceNameStr_in,
        interFaceDescribe = interFaceDescribe_in,
        interFacepath = interFacepath_in,
        interFaceBeginTime = interFaceBeginTime_in,
        interFaceEndTime = interFaceEndTime_in,
        interFaceBeginVersions= interFaceBeginVersions_in,
        interFaceEndVersions = interFaceEndVersions_in
        WHERE interFaceName = interFaceName_in ; 
        
	ELSE 
        INSERT SmartHomeInterFace_Table SET 
         interFaceNameStr = interFaceNameStr_in,
        interFaceDescribe = interFaceDescribe_in,
        interFacepath = interFacepath_in,
        interFaceBeginTime = interFaceBeginTime_in,
        interFaceEndTime = interFaceEndTime_in,
        interFaceBeginVersions= interFaceBeginVersions_in,
        interFaceEndVersions = interFaceEndVersions_in,
        interFaceName = interFaceName_in ; 
        
     END IF;   
    SELECT*FROM SmartHomeInterFace_Table;

END;

