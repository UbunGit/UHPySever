CREATE PROCEDURE p_RepalceUserScenario(IN userId_in INT, IN scenarioName_in TEXT, IN scenariopic_in TEXT)
  BEGIN 

	SELECT COUNT(scenarioName) INTO @Count 
    FROM SmartHomeUserScenario_Table 
    WHERE userId = userId_in AND
    scenarioName = scenarioName_in;
    
    IF @Count>0 THEN
    
        UPDATE SmartHomeUserScenario_Table SET 
        scenariopic = scenariopic_in
        WHERE userId = userId_in and scenarioName = scenarioName_in; 
        
	ELSE 
        INSERT SmartHomeUserScenario_Table SET 
        scenariopic = scenariopic_in,
        userId = userId_in,
        scenarioName = scenarioName_in; 
        
     END IF;   
END;

