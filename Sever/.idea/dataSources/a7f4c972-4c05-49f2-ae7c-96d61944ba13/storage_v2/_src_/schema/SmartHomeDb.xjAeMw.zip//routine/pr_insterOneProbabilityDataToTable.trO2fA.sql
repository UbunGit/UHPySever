CREATE PROCEDURE pr_insterOneProbabilityDataToTable(IN probability_in INT, IN TableName_in TEXT, IN outNO_in INT)
  begin
    set @outNO = outNO_in;
    set @beginlimit = probability_in-1;
	if @outNO = 0 then 
	
        set @excute_sql = concat("select outNO into @outNO from FC3DData_t order by outNO  limit ",@beginlimit,",1;");
        PREPARE sqlStr FROM @excute_sql;
        EXECUTE sqlStr;
		
    end if;

 
 
    drop temporary table if exists temtable;
	set @excute_sql = concat(
							"create temporary table temtable 
							select * from FC3DData_t where outNO<= ",@outNO," 
                            order by outNO desc limit 0,",probability_in,";");
	
	PREPARE sqlStr FROM @excute_sql;
	EXECUTE sqlStr;
 
	select count(*) into @temCount from  temtable;
    if @temCount=probability_in then
   
	select out_ge ,out_shi, out_bai,outdate into @ge,@shi,@bai,@outDate  from temtable where outNO = @outNO;

	select count(out_ge) into @countge from temtable where out_ge = @ge;
    select count(out_shi) into @countshi from temtable where out_shi = @shi;
    select count(out_bai) into @countbai from temtable where out_bai = @bai;
	
    set @excute_sql = concat(
							"replace ",TableName_in ,
                             " set  outNO= ",@outNO,
                             ", outDate= '",@outDate,
							 "',out_ge= ",@countge,
                             ", out_shi= ",@countshi,
                             ", out_bai= ",@countbai,
                             ";");
  
	PREPARE sqlStr FROM @excute_sql;
	EXECUTE sqlStr;
    end if;
END;

