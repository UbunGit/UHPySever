CREATE PROCEDURE p_GetUserInfo(IN userName_in TEXT)
  BEGIN 
    select userId ,userName ,userPassWord,userTel, userLevel ,userLogState from SmartHomeUser_Table 
    where userName = userName_in or userTel = userName_in;

END;

