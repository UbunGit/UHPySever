CREATE PROCEDURE p_ReplaceInterFaceParameter(IN parameterName_in        TEXT, IN parameterFatherName_in TEXT,
                                             IN parameterDescribe_in    TEXT, IN parameterCanNil_in TEXT,
                                             IN parameterEndTime_in     TEXT, IN parameterBeginVersions_in TEXT,
                                             IN parameterEndVersions_in TEXT, IN parameterType_in TEXT,
                                             IN parameterTypeuse_in     TEXT)
  BEGIN 

    SELECT COUNT(parameterName) INTO @Count 
    FROM SmartHomeParameter_Table 
    WHERE parameterName = parameterName_in 
	AND parameterFatherName = parameterFatherName_in;
    
    IF @Count>0 THEN
    
        UPDATE SmartHomeParameter_Table SET 
        parameterDescribe = parameterDescribe_in,
        parameterCanNil = parameterCanNil_in,
        parameterEndTime = parameterEndTime_in,
        parameterBeginVersions = parameterBeginVersions_in,
        parameterEndVersions = parameterEndVersions_in,
        parameterType = parameterType_in,
        parameterTypeuse = parameterTypeuse_in
        WHERE parameterName = parameterName_in  
	    AND parameterFatherName = parameterFatherName_in;  
        
	ELSE 
        INSERT SmartHomeParameter_Table SET 
        parameterDescribe = parameterDescribe_in,
        parameterCanNil = parameterCanNil_in,
        parameterEndTime = parameterEndTime_in,
        parameterBeginVersions = parameterBeginVersions_in,
        parameterEndVersions = parameterEndVersions_in,
        parameterType = parameterType_in,
        parameterTypeuse = parameterTypeuse_in,
		parameterName = parameterName_in, 
	    parameterFatherName = parameterFatherName_in; 
     END IF;   
    SELECT*FROM SmartHomeParameter_Table;

END;

