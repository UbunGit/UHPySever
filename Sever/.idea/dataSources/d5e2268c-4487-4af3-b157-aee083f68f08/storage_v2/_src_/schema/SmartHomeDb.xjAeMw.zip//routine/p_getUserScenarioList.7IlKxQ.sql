CREATE PROCEDURE p_getUserScenarioList(IN userId_in TEXT)
  BEGIN 

    select count(scenarioId) into @count  from SmartHomeUserScenario_Table 
    where userId = userId_in;
    
	set @userId = '000';
    if @count>0 then
      set @userId = userId_in;  
	end if;
     
     select scenarioId ,scenarioName,scenariopic from SmartHomeUserScenario_Table 
        where userId = @userId; 

END;

